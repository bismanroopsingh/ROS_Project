#!/usr/bin/env python3
"""
Hospital Robot Mission Runner
Route: Spawn → Supply Table → (wait 3s) → Nurses Desk
"""

import rclpy
import time
from rclpy.duration import Duration
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
from geometry_msgs.msg import PoseStamped
import math

def make_pose(nav, x, y, yaw_deg):
    """Helper: build a PoseStamped in map frame."""
    p = PoseStamped()
    p.header.frame_id = 'map'
    p.header.stamp = nav.get_clock().now().to_msg()
    p.pose.position.x = x
    p.pose.position.y = y
    p.pose.position.z = 0.0
    # Convert yaw (degrees) to quaternion (z, w only for 2D)
    yaw = math.radians(yaw_deg)
    p.pose.orientation.z = math.sin(yaw / 2.0)
    p.pose.orientation.w = math.cos(yaw / 2.0)
    return p

def main():
    rclpy.init()
    nav = BasicNavigator()

    # ── Set initial pose (where robot spawns in world/map frame) ──────────────
    initial_pose = make_pose(nav, x=0.0, y=-2.9, yaw_deg=0.0)
    nav.setInitialPose(initial_pose)

    # Wait for Nav2 to be fully active before sending goals
    nav.get_logger().info('Waiting for Nav2 to become active...')
    nav.waitUntilNav2Active(localizer='amcl', navigator='bt_navigator')
    nav.get_logger().info('Nav2 is active!')

    # ── GOAL 1: Supply Table ───────────────────────────────────────────────────
    # Table is at world (-8.5, 8.0). We stop 0.8m in front (y=7.2), facing it.
    supply_goal = make_pose(nav, x=-8.5, y=7.2, yaw_deg=90.0)  # facing +y (toward table)
    nav.get_logger().info('→ Navigating to Supply Table...')
    nav.goToPose(supply_goal)

    while not nav.isTaskComplete():
        feedback = nav.getFeedback()
        if feedback:
            nav.get_logger().info(
                f'  Distance to supply table: '
                f'{feedback.distance_remaining:.2f} m'
            )

    result = nav.getResult()
    if result == TaskResult.SUCCEEDED:
        nav.get_logger().info('✓ Reached Supply Table!')
    else:
        nav.get_logger().error(f'✗ Failed to reach Supply Table: {result}')

    # ── Wait at supply table ───────────────────────────────────────────────────
    nav.get_logger().info('⏱ Waiting 3 seconds at supply table...')
    time.sleep(3.0)
    nav.get_logger().info('✓ Done waiting. Heading to Nurses Desk...')

    # ── GOAL 2: Nurses Desk ───────────────────────────────────────────────────
    # Desk is at world (1.0, 1.0). We stop 1.2m in front (y=2.2), facing it.
    nurses_goal = make_pose(nav, x=1.0, y=2.2, yaw_deg=-90.0)  # facing -y (toward desk)
    nav.get_logger().info('→ Navigating to Nurses Desk...')
    nav.goToPose(nurses_goal)

    while not nav.isTaskComplete():
        feedback = nav.getFeedback()
        if feedback:
            nav.get_logger().info(
                f'  Distance to nurses desk: '
                f'{feedback.distance_remaining:.2f} m'
            )

    result = nav.getResult()
    if result == TaskResult.SUCCEEDED:
        nav.get_logger().info('✓ Reached Nurses Desk! Mission complete.')
    else:
        nav.get_logger().error(f'✗ Failed to reach Nurses Desk: {result}')

    nav.lifecycleShutdown()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
